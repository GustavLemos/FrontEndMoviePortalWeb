<?php
require_once 'connection.php';
/**
 * Created by PhpStorm.
 * User: lucas
 * Date: 9/9/17
 * Time: 1:23 PM
 */
error_reporting(E_ALL ^ E_NOTICE);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Loja</title>
    <link rel="stylesheet" href="assets/css/bootstrap-theme.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/loja.css">
</head>
<body>
<?php require_once 'navbar.php'; ?>
    <div class="container">
